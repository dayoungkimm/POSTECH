from multiprocessing import Pool
import numpy as np
import time
import csv
from utils import *
from sklearn.metrics import f1_score



""" Contains the part of speech tagger class. """


def evaluate(data, model):
    """Evaluates the POS model on some sentences and gold tags.

    This model can compute a few different accuracies:
        - whole-sentence accuracy
        - per-token accuracy
        - compare the probabilities computed by different styles of decoding

    You might want to refactor this into several different evaluation functions,
    or you can use it as is. 
    
    As per the write-up, you may find it faster to use multiprocessing (code included). 
    
    """
    processes = 4
    sentences = data[0]
    tags = data[1]
    n = len(sentences)
    k = n // processes
    n_tokens = sum([len(d) for d in sentences])
    unk_n_tokens = sum([1 for s in sentences for w in s if w not in model.word2idx.keys()])
    
    # Initializing predictions and probabilities
    predictions = {i: None for i in range(n)}
    probabilities = {i: None for i in range(n)}
    
    # Inference
    start = time.time()
    pool = Pool(processes=processes)
    res = [pool.apply_async(infer_sentences, [model, sentences[i:i+k], i]) for i in range(0, n, k)]
    ans = [r.get(timeout=None) for r in res]
    for a in ans:
        predictions.update(a)
    pool.close()
    pool.join()
    print(f"Inference Runtime: {(time.time()-start)/60:.2f} minutes.")
    
    # Computing probabilities
    start = time.time()
    pool = Pool(processes=processes)
    res = [pool.apply_async(compute_prob, [model, sentences[i:i+k], tags[i:i+k], i]) for i in range(0, n, k)]
    ans = [r.get(timeout=None) for r in res]
    for a in ans:
        probabilities.update(a)
    pool.close()
    pool.join()
    print(f"Probability Estimation Runtime: {(time.time()-start)/60:.2f} minutes.")
    
    # Token-level accuracy
    token_acc = sum([1 for i in range(n) for j in range(len(sentences[i])) if tags[i][j] == predictions[i][j]]) / n_tokens
    unk_token_acc = sum([1 for i in range(n) for j in range(len(sentences[i])) if tags[i][j] == predictions[i][j] and sentences[i][j] not in model.word2idx.keys()]) / unk_n_tokens
    
    # Calculate F1 score
    y_true = [tag for sentence_tags in tags for tag in sentence_tags]
    y_pred = [pred for i in range(n) for pred in predictions[i]]
    f1 = f1_score(y_true, y_pred, average='weighted')
    
    print(f"Token Accuracy: {token_acc:.4f}")
    print(f"Unknown Token Accuracy: {unk_token_acc:.4f}")
    print(f"F1 Score: {f1:.4f}")
    return token_acc, unk_token_acc, f1


class POSTagger():
    def __init__(self, emission_smoothing=1e-6, transition_smoothing=1e-6, scaling_factor=0.5):
        """Initializes the tagger model parameters and anything else necessary. """
        self.word2idx = {}
        self.tag2idx = {}
        self.idx2word = {}
        self.idx2tag = {}
        self.unigrams = None
        self.bigrams = None
        self.trigrams = None
        self.emissions = None
        self.emission_smoothing = emission_smoothing
        self.transition_smoothing = transition_smoothing
        self.scaling_factor = scaling_factor
    
    
    def get_unigrams(self):
        """
        Computes unigrams. 
        Tip. Map each tag to an integer and store the unigrams in a numpy array. 
        """
        tag_counts = np.zeros(len(self.tag2idx))
        for sentence in self.data[1]:
            for tag in sentence:
                tag_idx = self.tag2idx[tag]
                tag_counts[tag_idx] += 1
        self.unigrams = tag_counts / np.sum(tag_counts)

    def get_bigrams(self):        
        """
        Computes bigrams. 
        Tip. Map each tag to an integer and store the bigrams in a numpy array
             such that bigrams[index[tag1], index[tag2]] = Prob(tag2|tag1). 
        """
        bigram_counts = np.zeros((len(self.tag2idx), len(self.tag2idx)))
        for sentence in self.data[1]:
            for i in range(1, len(sentence)):
                prev_tag_idx = self.tag2idx[sentence[i-1]]
                curr_tag_idx = self.tag2idx[sentence[i]]
                bigram_counts[prev_tag_idx, curr_tag_idx] += 1
        row_sums = bigram_counts.sum(axis=1, keepdims=True)
        self.bigrams = (bigram_counts + self.transition_smoothing) / (row_sums + self.transition_smoothing * len(self.tag2idx))
    
    def get_trigrams(self):
        """
        Computes trigrams. 
        Tip. Similar logic to unigrams and bigrams. Store in numpy array. 
        """
        trigram_counts = np.zeros((len(self.tag2idx), len(self.tag2idx), len(self.tag2idx)))
        for sentence in self.data[1]:
            for i in range(2, len(sentence)):
                prev_prev_tag_idx = self.tag2idx[sentence[i-2]]
                prev_tag_idx = self.tag2idx[sentence[i-1]]
                curr_tag_idx = self.tag2idx[sentence[i]]
                trigram_counts[prev_prev_tag_idx, prev_tag_idx, curr_tag_idx] += 1
        row_sums = trigram_counts.sum(axis=2, keepdims=True)
        self.trigrams = (trigram_counts + self.transition_smoothing) / (row_sums + self.transition_smoothing * len(self.tag2idx))
    
    
    def get_emissions(self):
        """
        Computes emission probabilities. 
        Tip. Map each tag to an integer and each word in the vocabulary to an integer. 
             Then create a numpy array such that lexical[index(tag), index(word)] = Prob(word|tag) 
        """
        word_set = set([word for sentence in self.data[0] for word in sentence])
        self.word2idx = {word: i for i, word in enumerate(word_set)}
        self.idx2word = {i: word for word, i in self.word2idx.items()}
        
        emission_counts = np.zeros((len(self.tag2idx), len(self.word2idx)))
        for words, tags in zip(self.data[0], self.data[1]):
            for word, tag in zip(words, tags):
                word_idx = self.word2idx[word]
                tag_idx = self.tag2idx[tag]
                emission_counts[tag_idx, word_idx] += 1
        row_sums = emission_counts.sum(axis=1, keepdims=True)
        self.emissions = (emission_counts + self.emission_smoothing) / (row_sums + self.emission_smoothing * len(self.word2idx))
    

    def train(self, data):
        """Trains the model by computing transition and emission probabilities."""
        self.data = data
        self.all_tags = list(set([t for tag in data[1] for t in tag]))
        self.tag2idx = {self.all_tags[i]:i for i in range(len(self.all_tags))}
        self.idx2tag = {i:t for t,i in self.tag2idx.items()}
        
        # Compute unigrams, bigrams, trigrams, emissions
        self.get_unigrams()
        self.get_bigrams()
        self.get_trigrams()
        self.get_emissions()

    def sequence_probability(self, sequence, tags):
        """Computes the probability of a tagged sequence given the emission/transition
        probabilities.
        """
        log_prob = 0.0
        num_tags = len(self.all_tags)

        for i in range(len(sequence)):
            word = sequence[i]
            tag = tags[i]
            word_idx = self.word2idx.get(word, None)
            tag_idx = self.tag2idx[tag]

            # Emission probability
            if word_idx is not None:
                emission_prob = self.emissions[tag_idx, word_idx]
            else:
                emission_prob = self.emission_smoothing
            log_prob += np.log(emission_prob)

            # 전이 확률
            if i == 0:
                trans_prob = self.unigrams[tag_idx]
            else:
                prev_tag_idx = self.tag2idx[tags[i - 1]]
                trans_prob = self.bigrams[prev_tag_idx, tag_idx] ** self.scaling_factor
            log_prob += np.log(trans_prob)

        return log_prob

    def inference(self, sequence):
        """Tags a sequence with part of speech tags using greedy decoding."""
        tags = []
        num_tags = len(self.all_tags)

        for i in range(len(sequence)):
            word = sequence[i]
            word_idx = self.word2idx.get(word, None)

            # For unknown words
            if word_idx is not None:
                emission_probs = self.emissions[:, word_idx]
            else:
                emission_probs = np.ones(num_tags) / num_tags  # Uniform probability

            # For the first word, use unigram probabilities
            if i == 0:
                probs = self.unigrams * emission_probs
            else:
                prev_tag_idx = self.tag2idx[tags[i - 1]]
                trans_probs = self.bigrams[prev_tag_idx, :]
                probs = trans_probs * emission_probs

            # Choose the tag with the highest probability
            tag_idx = np.argmax(probs)
            tags.append(self.idx2tag[tag_idx])

        return tags

## Grid Search로 하이퍼파라미터 튜닝
if __name__ == "__main__":
    start_time = time.time()
    
    # 데이터 로드
    train_data = load_data("data/train_x.csv", "data/train_y.csv")
    dev_data = load_data("data/dev_x.csv", "data/dev_y.csv")
    test_data = load_data("data/test_x.csv")
    
    # 하이퍼파라미터 값의 범위 정의
    emission_smoothing_values = [1e-8, 1e-6, 1e-4, 1e-2]
    transition_smoothing_values = [1e-8, 1e-6, 1e-4, 1e-2]
    scaling_factors = [0.1, 0.5, 1.0]

    # 최적의 하이퍼파라미터를 저장하기 위한 변수
    best_params = None
    best_mean_f1_score = 0.0

    # 모든 하이퍼파라미터 조합에 대해 반복
    for emission_smoothing in emission_smoothing_values:
        for transition_smoothing in transition_smoothing_values:
            for scaling_factor in scaling_factors:
                # 모델 인스턴스 생성 (POSTagger 클래스 사용)
                pos_tagger = POSTagger(
                    emission_smoothing=emission_smoothing, 
                    transition_smoothing=transition_smoothing, 
                    scaling_factor=scaling_factor
                )
                
                # 모델 학습
                train_start = time.time()
                pos_tagger.train(train_data)
                train_end = time.time()
                train_time = train_end - train_start
                print(f"Training time: {train_end - train_start:.2f} seconds")

                # 모델 평가 (개발 데이터를 사용하여 F1 점수 계산)
                eval_start = time.time()
                dev_predictions = [pos_tagger.inference(sentence) for sentence in dev_data[0]]
                eval_end = time.time()
                eval_time = eval_end - eval_start
                print(f"Evaluation time: {eval_end - eval_start:.2f} seconds")
                
                
                # dev_predictions와 dev_data[1]을 평탄화하여 1차원 배열로 변환
                flattened_dev_predictions = [tag for sentence_tags in dev_predictions for tag in sentence_tags]
                flattened_dev_labels = [tag for sentence_tags in dev_data[1] for tag in sentence_tags]
                
                # F1 점수 계산
                mean_f1 = f1_score(flattened_dev_labels, flattened_dev_predictions, average='macro')
                print(f"Mean F1 Score for parameters (emission_smoothing={emission_smoothing}, "
                      f"transition_smoothing={transition_smoothing}, scaling_factor={scaling_factor}): {mean_f1:.4f}")
                
                # 최적의 F1 점수를 찾으면 업데이트
                if mean_f1 > best_mean_f1_score:
                    best_mean_f1_score = mean_f1
                    best_params = {
                        'emission_smoothing': emission_smoothing,
                        'transition_smoothing': transition_smoothing,
                        'scaling_factor': scaling_factor
                    }

    # 최적의 하이퍼파라미터로 모델 재학습 및 테스트
    print("\n최적의 하이퍼파라미터 조합:", best_params)
    print("최고의 Mean F1 Score:", best_mean_f1_score)
    
    # 최적의 하이퍼파라미터로 모델 생성
    pos_tagger = POSTagger(
        emission_smoothing=best_params['emission_smoothing'],
        transition_smoothing=best_params['transition_smoothing'],
        scaling_factor=best_params['scaling_factor']
    )
    pos_tagger.train(train_data)
    
     # 모델 학습
    final_train_start = time.time()
    pos_tagger.train(train_data)
    final_train_end = time.time()
    final_train_time = final_train_end - final_train_start
    
    # 테스트 데이터에 대한 예측 수행
    inference_start = time.time()
    test_predictions = [pos_tagger.inference(sentence) for sentence in test_data]
    inference_end = time.time()
    inference_time = inference_end - inference_start
    
    
    processed_test_ids = [i for i in range(len(test_predictions))]
    
    # 결과를 CSV 파일로 저장
    with open("data/test_y.csv", "w", newline='') as f:
        writer = csv.writer(f, quoting=csv.QUOTE_NONNUMERIC)
        writer.writerow(['id', 'tag'])
        for idx, tag in zip(processed_test_ids, test_predictions):
            writer.writerow([idx, tag])
        
    end_time = time.time()
    total_time = end_time - start_time
    
    
    # 모든 시간을 하나의 스크린샷에 나타내기 위한 최종 출력
    print("\n========= Summary of Running Times =========")
    print(f"Total execution time: {total_time:.2f} seconds")
    print(f"Final training time: {final_train_time:.2f} seconds")
    print(f"Inference time: {inference_time:.2f} seconds")
