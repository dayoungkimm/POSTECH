from multiprocessing import Pool 
import numpy as np 
import time 
import csv 
from utils import * 
from sklearn.metrics import f1_score #f1 score로 성능 계산 위해 f1_score 추가



""" Contains the part of speech tagger class. """


def evaluate(data, model, train_time, inference_time):
    """Evaluates the POS model on some sentences and gold tags.
    
    1. 평균 확률 계산에서 예외 처리 추가 (예외 처리로 인해 코드 오류 방지)
    2. 문장 정확도 계산 방식을 구간을 나누는 복잡한 방식 대신 문장을 단위로 처리하여 코드를 간결화함
    3. 평가 시간 계산 추가 
    4. 코드의 구조적 간결성 (불필요한 구간 나누기 등 삭제)
    """

    processes = 4
    sentences = data[0] 
    tags = data[1] 
    n = len(sentences) 
    k = n//processes 
    n_tokens = sum([len(d) for d in sentences]) 
    unk_n_tokens = sum([1 for s in sentences for w in s if w not in model.word2idx.keys()])
    predictions = {i:None for i in range(n)} 

    
    # Inference 시간 측정 및 실행 
    start = time.time() 
    pool = Pool(processes=processes) 
    res = []
    for i in range(0, n, k):
        res.append(pool.apply_async(infer_sentences, [model, sentences[i:i+k], i]))
    ans = [r.get(timeout=None) for r in res] 
    predictions = dict()
    for a in ans:
        predictions.update(a)
    inference_runtime = (time.time() - start) / 60 
    
    # Probability Estimation 시간 측정 및 실행
    start = time.time() 
    pool = Pool(processes=processes) 
    res = []
    for i in range(0, n, k):
        res.append(pool.apply_async(compute_prob, [model, sentences[i:i+k], tags[i:i+k], i])) 
    ans = [r.get(timeout=None) for r in res] 
    probabilities = dict()
    for a in ans:
        probabilities.update(a) 
    probability_estimation_runtime = (time.time() - start) / 60 

    # 정확도 계산 (토큰 기반 정확도, 문장 전체 정확도, unknown 토큰 정확도 등)
    token_acc = sum([1 for i in range(n) for j in range(len(sentences[i])) if tags[i][j] == predictions[i][j]]) / n_tokens
    unk_token_acc = sum([1 for i in range(n) for j in range(len(sentences[i])) if tags[i][j] == predictions[i][j] and sentences[i][j] not in model.word2idx.keys()]) / unk_n_tokens
    # 각 문장 단위로 태그의 일치 여부 확인
    whole_sent_acc = sum([1 if tags[i] == predictions[i] else 0 for i in range(n)]) / n

    # 확률의 평균값 계산
    # "n"이 0인 될 경우를 대비하여 "n>0" 조건 추가한 뒤 평균 계산 >> 프로그램이 실행되는 도중에 데이터가 없거나 계산할 확률이 없을 때의 오류를 방지하기 위한 처리
    mean_probabilities = sum(probabilities.values()) / n if n > 0 else 0

    # 성능 측정에 도움을 주기 위해 전체 평가 시간 계산 (probability estimation 시간과 inference 시간을 합산)
    evaluation_time = probability_estimation_runtime * 60 + inference_runtime * 60  # minutes to seconds

    
    # Confusion matrix 그리기
    confusion_matrix(model.tag2idx, model.idx2tag, predictions.values(), tags, 'cm.png')
    
    

    # 결과 출력 (마지막에 한번에 정리함)
    print(f"Training time: {train_time:.2f} seconds")
    print(f"Inference Runtime: {inference_runtime:.6f} minutes")
    print(f"Probability Estimation Runtime: {probability_estimation_runtime:.6f} minutes")
    print(f"Whole sent acc: {whole_sent_acc:.6f}")
    print(f"Mean Probabilities: {mean_probabilities:.6f}")
    print(f"Token acc: {token_acc:.6f}")
    print(f"Unk token acc: {unk_token_acc:.6f}")
    print(f"Evaluation time: {evaluation_time:.2f} seconds")
    print(f"Inference time: {inference_time:.2f} seconds")

    # 필요한 경우 결과를 반환 (추후 사용을 위해)
    return {
        'inference_runtime': inference_runtime,
        'probability_estimation_runtime': probability_estimation_runtime,
        'whole_sent_acc': whole_sent_acc,
        'mean_probabilities': mean_probabilities,
        'token_acc': token_acc,
        'unk_token_acc': unk_token_acc
    }

class POSTagger():
    def __init__(self, emission_smoothing=1e-6, transition_smoothing=1e-6, scaling_factor=0.5):
        """Initializes the tagger model parameters and anything else necessary. """
        self.word2idx = {}
        self.tag2idx = {}
        self.idx2word = {}
        self.idx2tag = {}
        self.unigrams = None
        self.bigrams = None
        self.trigrams = None
        self.emissions = None
        self.emission_smoothing = emission_smoothing #  emission 확률 계산 시 사용될 스무딩 값 (작은 값을 더해 줘서 확률이 0이 되는 것을 방지)
        self.transition_smoothing = transition_smoothing #  transition 확률 계산 시 사용될 스무딩 값 (같은 이유로 0 확률을 방지)
        self.scaling_factor = scaling_factor # 모델에서 transition 확률 계산 시 사용할 스케일링 값 (확률을 조정하기 위해 사용)
        
                
    def get_unigrams(self):
        """
        Computes unigrams. 
        """
        # 태그별 빈도를 저장할 배열 생성
        tag_counts = np.zeros(len(self.tag2idx)) # 태그 수만큼의 배열 생성 (빈도 저장)
        
        # 각 문장에서 태그의 빈도를 계산하여 배열에 저장
        for sentence in self.data[1]:
            for tag in sentence:
                tag_idx = self.tag2idx[tag] # 태그에 해당하는 인덱스 찾기
                tag_counts[tag_idx] += 1 # 해당 태그의 빈도수 증가
                
        # 전체 태그 빈도수에서 각 태그가 등장한 빈도를 나누어 확률로 변환
        self.unigrams = tag_counts / np.sum(tag_counts) # 빈도수를 확률로 변환

    def get_bigrams(self):        
        """
        Computes bigrams. 
        """
        # bigram (태그 두 개 연속 등장) 빈도를 저장할 2D 배열 생성
        bigram_counts = np.zeros((len(self.tag2idx), len(self.tag2idx))) # 태그 2개 간의 빈도 저장할 배열 생성
        
        # 각 문장에서 연속된 두 태그 간의 빈도를 계산하여 배열에 저장
        for sentence in self.data[1]:
            for i in range(1, len(sentence)):
                prev_tag_idx = self.tag2idx[sentence[i-1]] # 이전 태그의 인덱스
                curr_tag_idx = self.tag2idx[sentence[i]] # 현재 태그의 인덱스
                bigram_counts[prev_tag_idx, curr_tag_idx] += 1 # 전이 빈도수 증가
        
        # 각 태그의 총 빈도를 계산하여 bigram 확률로 변환 (스무딩 적용)
        row_sums = bigram_counts.sum(axis=1, keepdims=True) # 각 태그의 총 빈도수 계산
        # 전이 확률을 빈도수에서 확률로 변환
        self.bigrams = (bigram_counts + self.transition_smoothing) / (row_sums + self.transition_smoothing * len(self.tag2idx))
        # 스무딩을 적용하여 확률이 0이 되지 않도록 방지
        
    def get_trigrams(self):
        """
        Computes trigrams. 
        """
        # trigram (태그 세 개 연속 등장) 빈도를 저장할 3D 배열 생성
        trigram_counts = np.zeros((len(self.tag2idx), len(self.tag2idx), len(self.tag2idx))) # 3개 태그 간 빈도 저장할 배열
        
        # 각 문장에서 연속된 세 태그 간의 빈도를 계산하여 배열에 저장
        for sentence in self.data[1]:
            for i in range(2, len(sentence)):
                prev_prev_tag_idx = self.tag2idx[sentence[i-2]] # 이전 이전 태그 인덱스
                prev_tag_idx = self.tag2idx[sentence[i-1]] # 이전 태그 인덱스
                curr_tag_idx = self.tag2idx[sentence[i]] # 현재 태그 인덱스
                trigram_counts[prev_prev_tag_idx, prev_tag_idx, curr_tag_idx] += 1 # 빈도수 증가
        
        # 각 trigram의 빈도수를 확률로 변환 (스무딩 적용)
        row_sums = trigram_counts.sum(axis=2, keepdims=True) # 빈도수의 합
        # 빈도수에서 확률로 변환
        self.trigrams = (trigram_counts + self.transition_smoothing) / (row_sums + self.transition_smoothing * len(self.tag2idx))
        # 스무딩을 적용하여 확률이 0이 되는 것을 방지
    
    def get_emissions(self):
        """
        Computes emission probabilities. 
        """
        # 모든 문장에 포함된 단어 목록을 생성하여 단어 -> 인덱스 매핑을 생성
        word_set = set([word for sentence in self.data[0] for word in sentence]) # 모든 문장에서 단어 목록 생성
        self.word2idx = {word: i for i, word in enumerate(word_set)} # 단어 -> 인덱스 매핑 생성
        self.idx2word = {i: word for word, i in self.word2idx.items()} # 인덱스 -> 단어 매핑 생성
        
        # 태그와 단어 간의 emission 빈도를 저장할 2D 배열 생성
        emission_counts = np.zeros((len(self.tag2idx), len(self.word2idx))) # 태그와 단어 간의 빈도 저장 배열
        
        # 각 문장에서 단어와 태그 쌍을 확인하여 빈도수를 계산
        for words, tags in zip(self.data[0], self.data[1]):
            for word, tag in zip(words, tags):
                word_idx = self.word2idx[word] # 단어 인덱스
                tag_idx = self.tag2idx[tag] # 태그 인덱스
                emission_counts[tag_idx, word_idx] += 1 # 빈도수 증가
        
        # 각 태그에 대해 빈도수를 확률로 변환 (스무딩 적용)
        row_sums = emission_counts.sum(axis=1, keepdims=True) # 각 태그의 총 빈도수
        # 빈도수에서 확률로 변환 (smoothing 적용)
        self.emissions = (emission_counts + self.emission_smoothing) / (row_sums + self.emission_smoothing * len(self.word2idx))
        # 스무딩을 적용하여 확률이 0이 되는 것을 방지

    def train(self, data):
        """Trains the model by computing transition and emission probabilities."""
        self.data = data
        self.all_tags = list(set([t for tag in data[1] for t in tag])) # 전체 태그 목록 생성
        self.tag2idx = {self.all_tags[i]:i for i in range(len(self.all_tags))} # 태그 -> 인덱스 매핑
        self.idx2tag = {i:t for t,i in self.tag2idx.items()} # 인덱스 -> 태그 매핑
        
        # Compute unigrams, bigrams, trigrams, emissions
        self.get_unigrams()
        self.get_bigrams()
        self.get_trigrams()
        self.get_emissions()

    def handle_unknown_word(self, word):
        """
        모르는 단어를 처리하는 규칙 기반 방법.
        훈련 데이터에 없던 새로운 단어가 등장했을 때 모델의 성능을 보장하기 위해 추가함
        """
        if word.isdigit():  # 숫자인 경우
            return 'CD'
        elif word[0].isupper(): # 대문자로 시작하는 경우
            return 'NNP'
        elif word.endswith('ing'):  # 'ing'로 끝나는 경우
            return 'VBG'
        elif word.endswith('ed'):   # 'ed'로 끝나는 경우
            return 'VBD'
        elif word.endswith('ly'):   # 'ly'로 끝나는 경우
            return 'RB'
        elif word.endswith('s'):    # 's'로 끝나는 경우
            return 'NNS'
        else:
            return 'NN' # 기본값으로 명사

    
    def sequence_probability(self, sequence, tags):
        """
        태깅된 시퀀스의 확률 계산.
        
        1. 모르는 단어에 대해 더 적절한 태그를 할당하고, 스무딩 값을 사용하여 처리함
        2. trigram 확률까지 고려하여 태그 간의 의존성을 더 정확하게 반영함
        3. scaling_factor를 사용하여 transition 확률을 더 유연하게 조정
        4. 고정된 스무딩 값 대신, 학습 시 설정된 값을 사용하여 상황에 맞게 스무딩이 적용됨 
        """
        log_prob = 0.0  # 로그 확률 초기화
    

        for i in range(len(sequence)):
            word = sequence[i]
            tag = tags[i]
            word_idx = self.word2idx.get(word, None)    # 단어 인덱스 찾기
            tag_idx = self.tag2idx[tag] # 태그 인덱스 찾기

            # Emission probability 계산
            if word_idx is not None:
                emission_prob = self.emissions[tag_idx, word_idx]
            else:
                # 모르는 단어에 대한 처리 >> handle_unknown_word() 함수를 사용하여 단어의 특성에 따라 적절한 태그 할당
                # 모르는 단어에 대해서는 스무딩 값을 적용
                unknown_tag = self.handle_unknown_word(word)
                tag_idx = self.tag2idx[unknown_tag]
                emission_prob = self.emission_smoothing
            log_prob += np.log(emission_prob)

            # trigram 사용하여 Transition Probability 계산
            ## trigram 확률까지 고려하여 전이 확률을 더 정확하게 계산 / scaling_factor를 적용해 확률 값을 조정
            if i == 0:
                trans_prob = self.unigrams[tag_idx] # 첫 태그는 unigram 확률 사용
            elif i == 1:
                prev_tag_idx = self.tag2idx[tags[i - 1]]    # 이전 태그 인덱스
                trans_prob = self.bigrams[prev_tag_idx, tag_idx] ** self.scaling_factor # bigram 확률
            else:
                prev_prev_tag_idx = self.tag2idx[tags[i - 2]]   # 이전 이전 태그 인덱스
                prev_tag_idx = self.tag2idx[tags[i - 1]]     # 이전 태그 인덱스
                trans_prob = self.trigrams[prev_prev_tag_idx, prev_tag_idx, tag_idx] ** self.scaling_factor # trigram 확률
            log_prob += np.log(trans_prob)

        return log_prob

    def inference(self, sequence):
        """
        태그 예측 (trigram 디코딩).
        
        1. 모르는 단어를 처리할 때, 균등 확률 적용 대신 단어의 특성에 따라 적절한 태그를 할당하고 해당 태그의 확률을 1로 설정하여 정확도를 향상시킴
        2. trigram을 사용해 이전 두 태그까지 고려한 전이 확률을 계산하여 태그 간의 관계를 더 정밀하게 반영
        3. 첫 번째 단어는 unigram 확률, 두 번째 단어는 bigram 확률, 그 이후에는 trigram 확률을 사용해 더 세밀한 태깅을 수행
        4. 상황에 맞는 전이 확률을 계산, 태그 예측의 정밀도를 향상시킴
        """
        tags = [] # 예측 태그 저장할 리스트
        num_tags = len(self.all_tags)  # 전체 태그 수

        for i in range(len(sequence)):
            word = sequence[i]
            word_idx = self.word2idx.get(word, None)    # 단어 인덱스 찾기

            if word_idx is not None:
                emission_probs = self.emissions[:, word_idx]    # 단어에 대한 emission 확률
            else:
                # 모르는 단어 처리
                unknown_tag = self.handle_unknown_word(word)
                tag_idx = self.tag2idx[unknown_tag]
                emission_probs = np.zeros(num_tags) # 모든 태그에 대한 확률 0
                emission_probs[tag_idx] = 1  # 모르는 단어에 대한 확률 1 할당

            if i == 0:
                probs = self.unigrams * emission_probs  # 첫 번째 태그의 경우 unigram 확률 사용
            elif i == 1:
                prev_tag_idx = self.tag2idx[tags[i - 1]]    # 이전 태그 인덱스
                trans_probs = self.bigrams[prev_tag_idx, :] # bigram 확률 사용
                probs = trans_probs * emission_probs
            else:
                prev_prev_tag_idx = self.tag2idx[tags[i - 2]]   # 이전 이전 태그 인덱스
                prev_tag_idx = self.tag2idx[tags[i - 1]]    # 이전 태그 인덱스
                trans_probs = self.trigrams[prev_prev_tag_idx, prev_tag_idx, :] # trigram 확률 사용
                probs = trans_probs * emission_probs

            tag_idx = np.argmax(probs)  # 가장 높은 확률을 가진 태그 선택
            tags.append(self.idx2tag[tag_idx])  # 예측된 태그 추가

        return tags
    
def find_best_hyperparameters(train_data, dev_data):
    """
    최적의 하이퍼파라미터를 찾는 함수.
    1. 여러 하이퍼파라미터 조합을 탐색하여, 최적의 모델 성능을 이끌어낼 수 있는 파라미터 세트를 자동으로 찾기 위해 추가됨
    2. 이를 통해 모델 튜닝 과정을 자동화하여 수동으로 파라미터를 설정하는 번거로움을 덜 수 있으며, 다양한 조합을 시도하여 성능 최적화를 수행할 수 있음.
    3. F1 스코어를 기준으로 가장 성능이 좋은 조합을 찾는 것이 장점
    
    Parameters:
        train_data (tuple): 학습 데이터 (train_x, train_y) 형식으로 제공
        dev_data (tuple): 개발 데이터 (dev_x, dev_y) 형식으로 제공
    
    Returns:
        best_params (dict): 최적의 하이퍼파라미터 세트
        best_mean_f1_score (float): 해당 하이퍼파라미터에서의 최고 F1 점수
    """
    # 하이퍼파라미터 값의 범위 정의
    ## 모델의 성능을 개선하기 위해 emission 및 transition 확률 계산 시 사용하는 스무딩 값(emission_smoothing, transition_smoothing)
    ## 그리고 transition 확률 계산에 사용되는 scaling_factor 값을 다양한 범위에서 탐색
    emission_smoothing_values = [1e-8, 1e-6, 1e-4, 1e-2]    # emission smoothing 값들
    transition_smoothing_values = [1e-8, 1e-6, 1e-4, 1e-2]  # transition smoothing 값들
    scaling_factors = [0.1, 0.5, 1.0]   # scaling factor 값들

    best_params = None  # 최적의 파라미터 저장할 변수
    best_mean_f1_score = 0.0    # 최적의 F1 스코어 저장할 변수
    
    # 모든 파라미터 조합에 대해 성능을 측정하여 최적의 값을 찾는다
    ## 여러 파라미터 조합을 통해 성능을 비교하는 방식으로, 각 하이퍼파라미터의 조합이 모델 성능에 미치는 영향을 평가
    for emission_smoothing in emission_smoothing_values:
        for transition_smoothing in transition_smoothing_values:
            for scaling_factor in scaling_factors:
                # 각 하이퍼파라미터 세트에 대해 POSTagger 모델을 초기화
                pos_tagger = POSTagger(
                    emission_smoothing=emission_smoothing,
                    transition_smoothing=transition_smoothing,
                    scaling_factor=scaling_factor
                )
                
                # 학습 데이터로 모델 훈련
                pos_tagger.train(train_data)   
                
                # 개발 데이터에 대해 모델의 예측 수행
                dev_predictions = [pos_tagger.inference(sentence) for sentence in dev_data[0]]
                
                # 예측된 태그와 실제 태그를 펼쳐서 리스트로 생성
                flattened_dev_predictions = [tag for sentence_tags in dev_predictions for tag in sentence_tags]
                flattened_dev_labels = [tag for sentence_tags in dev_data[1] for tag in sentence_tags]
                
                # F1 점수 계산하여 모델 성능 평가
                mean_f1 = f1_score(flattened_dev_labels, flattened_dev_predictions, average='weighted')
                
                # 현재까지의 최적 F1 점수와 비교하여 더 높은 성능을 보이면 하이퍼파라미터를 갱신
                if mean_f1 > best_mean_f1_score:
                    best_mean_f1_score = mean_f1
                    best_params = {
                        'emission_smoothing': emission_smoothing,
                        'transition_smoothing': transition_smoothing,
                        'scaling_factor': scaling_factor
                    }

     # 최적의 하이퍼파라미터와 해당 하이퍼파라미터에서의 최고 F1 점수를 반환
    return best_params, best_mean_f1_score  

def save_predictions_to_csv(predictions, filename="data/test_y.csv"):
    """
    예측 결과를 CSV 파일로 저장하는 함수.
    
    Parameters:
        predictions (list): 예측된 POS 태그 리스트
        filename (str): 저장할 파일명
    """
    # 주어진 예측 결과를 지정된 CSV 파일로 저장
    with open(filename, "w", newline='') as f:
        f.write("id,tag\n")  # 헤더 작성
        idx = 0
        for sentence_tags in predictions:
            for tag in sentence_tags:
                # 태그 값에 따옴표 하나 추가하여 작성
                f.write(f'{idx},"{tag}"\n')
                idx += 1

def main():
    """
    1. 하이퍼파라미터 최적화 추가 : find_best_hyperparameters() 함수를 호출하여 자동으로 최적의 하이퍼파라미터를 찾아 성능을 최적화
    2. main() 함수로 모든 흐름을 함수 단위로 분리하여 코드를 구조화
    """
    start_time = time.time()    # 프로그램 시작 시간 기록
    
    # 데이터 로드
    train_data = load_data("data/train_x.csv", "data/train_y.csv")
    dev_data = load_data("data/dev_x.csv", "data/dev_y.csv")
    test_data = load_data("data/test_x.csv")
    
    # 최적의 하이퍼파라미터를 찾기 위해 함수 호출
    best_params, best_mean_f1_score = find_best_hyperparameters(train_data, dev_data)
    
    # 최적의 하이퍼파라미터로 모델 재학습 및 테스트
    pos_tagger = POSTagger(
        emission_smoothing=best_params['emission_smoothing'],
        transition_smoothing=best_params['transition_smoothing'],
        scaling_factor=best_params['scaling_factor']
    )
    
    # 모델 학습
    final_train_start = time.time() # 학습 시작 시간
    pos_tagger.train(train_data)    # 학습 데이터로 모델 학습
    final_train_end = time.time()   # 학습 완료 시간
    final_train_time = final_train_end - final_train_start  # 학습 시간 계산
    
    # 테스트 데이터에 대한 예측 수행
    inference_start = time.time()   # Inference 시작 시간
    test_predictions = [pos_tagger.inference(sentence) for sentence in test_data]   # 테스트 데이터 예측
    inference_end = time.time() # Inference 완료 시간
    inference_time = (inference_end - inference_start) / 60  # Inference 시간 (분 단위로 변환)
    
    # 예측 결과를 CSV로 저장
    save_predictions_to_csv(test_predictions)
    
   # dev set을 사용하여 모델 평가
    eval_results = evaluate(dev_data, pos_tagger, final_train_time, inference_time)
    
    # 전체 프로그램 종료 시간 기록
    end_time = time.time()
    total_execution_time = end_time - start_time  # 프로그램 전체 실행 시간 계산
        
 
    
    
    print(f"Total execution time: {total_execution_time:.2f} seconds")  # 총 실행 시간 출력
   


if __name__ == "__main__":
    main()
